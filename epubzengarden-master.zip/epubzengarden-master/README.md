epubzengarden
=============

My version of [http://epubzengarden.com](http://epubzengarden.com).

I've simply grabbed Liza Daly's lovely little [epub.js](http://code.google.com/p/epub-tools/source/browse/#svn/trunk/epubtools/epubjs) reading system, and the contributed styles from [http://epubzengarden.com](http://epubzengarden.com).

The intention is to use this as a starting point to put together some examples of epubs which demonstrate:

1. typographic beauty
1. responsive design (e.g. using media queries)